function clickMenu() {
    var itensMenu = document.getElementById('itens')
    if (itensMenu.style.display == 'block') {
        itensMenu.style.display = 'none'
    } else {
        itensMenu.style.display = 'block'
    }
}